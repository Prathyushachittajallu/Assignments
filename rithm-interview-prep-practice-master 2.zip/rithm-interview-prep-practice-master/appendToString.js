// add whatever parameters you deem necessary - good luck!
function appendToString(arg1, arg2) {
    return arg1 + arg2
}

let output = appendToString("", "test");

console.log(output)